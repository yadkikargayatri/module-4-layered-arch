﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EntityFrameworkUsingEF.Models;

namespace EntityFrameworkUsingEF.Controllers
{
    public class StaffController : Controller
    {
        //
        // GET: /Staff/
        Training_18Jan2017_TalwadeEntities context = new Training_18Jan2017_TalwadeEntities();
        public ActionResult Index()
        {
            
            return View(context.Staff_Master);
        }
        public ActionResult Details(int id)
        {
            return View(context.Staff_Master.Find(id));
        }
        public ActionResult CreateStaff()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateStaff(Staff_Master staff)
        {
            if (ModelState.IsValid)
            {
                context.Staff_Master.Add(staff);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(staff);
            }
        }

        public ActionResult Edit(int id)
        {
            return View(context.Staff_Master.Find(id));
        }

        [HttpPost]
        public ActionResult Edit(Staff_Master staff)
        {
            if (ModelState.IsValid)
            {
                Staff_Master stf = new Staff_Master();
                stf=context.Staff_Master.First(s => s.Staff_Code ==staff.Staff_Code);
                stf.Staff_Name = staff.Staff_Name;
                stf.Salary = staff.Salary;
                stf.Mgr_code = staff.Mgr_code;
                context.SaveChanges();
                return RedirectToAction("Index");

            }
            else
            {
                return View(staff);
            }
        }
    
        



       
        public ActionResult Delete()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Delete(int id)
        {
            Staff_Master staff = new Staff_Master();

            if (ModelState.IsValid)
            {
                staff = context.Staff_Master.Find(id);
                context.Staff_Master.Remove(staff);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(staff);
            }
        }
    }


 }

