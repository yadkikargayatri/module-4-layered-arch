﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.DAL;

namespace EMS.BL
{
    public class EmployeeValidation
    {
        public static int InsertEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try 
            {
                recordsAffected = EmployeeOperations.InsertEmployee(emp);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = EmployeeOperations.UpdateEmployee(emp);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteEmployee(int empID)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = EmployeeOperations.DeleteEmployee(empID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static DataTable DisplayEmployee()
        {
            DataTable dt = null;

            try
            {
                dt = EmployeeOperations.DisplayEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dt;
        }

        public static Employee SearchEmployee(int empID)
        {
            Employee emp = null;

            try
            {
                emp = EmployeeOperations.SearchEmployee(empID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }
    }
}
