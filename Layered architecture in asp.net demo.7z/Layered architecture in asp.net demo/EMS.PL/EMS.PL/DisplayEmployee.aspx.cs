﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.BL;
using EMS.Exception;
using EMS.Entity;
using System.Data;

namespace EMS.PL
{
    public partial class DisplayEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"].ToString();
                Master.LogoutVisible = true;
                Master.MenuVisible = true;

                try 
                {
                    DataTable dt = EmployeeValidation.DisplayEmployee();
                    if (dt.Rows.Count > 0)
                    {
                        gvEmployee.DataSource = dt;
                        gvEmployee.DataBind();
                    }
                    else
                        throw new EmployeeException("Employee Data not Available");
                }
                catch (EmployeeException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SystemException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
        }
    }
}